---
title: SECRET
---

# 0001

```
你好
안 a ni
녕 ni ang
하 ha
세 sei
요 you

나 na
는 nen
매 mei ai
우 wu
그 ku wu
립 li
다 ta

我很想念你
나는 매우 그립다
na nen mei o ku li pu ta
```

# 0002

```
我喜欢你
나 너 좋아해
na nao shao a hai
나 na
너 nao
좋 shao
아 a
해 hai
```

# 0003

```
小仙女
작은 선녀
qia ge ni cang niao
작 qia
은 ben
선 cang
녀 niao
```

