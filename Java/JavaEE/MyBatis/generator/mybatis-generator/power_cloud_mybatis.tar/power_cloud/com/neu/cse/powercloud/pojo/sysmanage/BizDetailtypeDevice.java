package com.neu.cse.powercloud.pojo.sysmanage;

public class BizDetailtypeDevice {
    private Integer id;

    private Integer num;

    private String expression;

    private Integer registernum;

    private String unit;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getNum() {
        return num;
    }

    public void setNum(Integer num) {
        this.num = num;
    }

    public String getExpression() {
        return expression;
    }

    public void setExpression(String expression) {
        this.expression = expression;
    }

    public Integer getRegisternum() {
        return registernum;
    }

    public void setRegisternum(Integer registernum) {
        this.registernum = registernum;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }
}