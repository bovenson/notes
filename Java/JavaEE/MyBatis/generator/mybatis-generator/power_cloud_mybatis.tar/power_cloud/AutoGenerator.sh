#!/bin/bash
cd ..
java -jar mybatis-generator-core-1.3.5.jar -configfile power_cloud/power-cloud.xml -overwrite
